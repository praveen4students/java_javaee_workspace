
package com.cognizant.openid.util;

import java.io.FileInputStream;
import java.util.*;

public class Configurations {
	
	/*public static Properties config;
	
	public static void loadProperties() 
	{
		try
		{
			FileInputStream file = new FileInputStream("C:/app/property/openid.properties");
			config = new Properties();
			config.load(file);
			file.close();
		}
		catch (Exception ex)
		{
			System.out.println("Error while opening the configuration file : openid.properties");
			System.out.println("Exception = " + ex.toString());			
		}
	}
	

	public static String getProperty(String strKey, String strDefault) {
		
		String strValue = getProperty(strKey);
		if (strValue == null) {
			return strDefault;
		}
		return strValue;
	}
	
	public static String getProperty (String strKey) {
		return config.getProperty(strKey);
	}*/
}
