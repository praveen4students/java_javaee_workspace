package com.cognizant.openid.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.HashSet;
import java.util.Set;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.expressme.openid.Association;
import org.expressme.openid.Authentication;
import org.expressme.openid.Endpoint;
import org.expressme.openid.OpenIdException;
import org.expressme.openid.OpenIdManager;

import com.cognizant.openid.util.Configurations;


public class ValidateOpenIdServlet extends HttpServlet {

	public static final long serialVersionUID = 1L;
	
    static final long ONE_HOUR = 3600000L;
    static final long TWO_HOUR = ONE_HOUR * 2L;
    static final String ATTR_MAC = "openid_mac";
    static final String ATTR_ALIAS = "openid_alias";
    
    private OpenIdManager manager;

    @Override
    public void init() throws ServletException 
    {
        super.init();
        manager = new OpenIdManager();
        //Configurations.loadProperties();
        String hostName = "http://li-lbcapp-dev-v11:9082";
        manager.setRealm(hostName);
        manager.setReturnTo(hostName+"/ValidateOpenID/openid");
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String op = request.getParameter("op");
        
        if (op==null) 
        {
        	PrintWriter out = response.getWriter();
        	out.println("op Value ----->"+op);
        	try
        	{
        		out.println("Inside NULL");out.flush();
                // check sign on result from Google or Yahoo:
                checkNonce(request.getParameter("openid.response_nonce"));
                out.println("AAAAAAAA");out.flush();
                // get authentication:
                byte[] mac_key = (byte[]) request.getSession().getAttribute(ATTR_MAC);
                out.println("BBBBBBBB");out.flush();
                String alias = (String) request.getSession().getAttribute(ATTR_ALIAS);
                out.println("CCCCCCCCCC");out.flush();
                Authentication auth = manager.getAuthentication(request, mac_key, alias);
                out.println("DDDDDDDDDDDD");out.flush();
                response.setContentType("text/html; charset=UTF-8");
                //request.setAttribute("Authentication", auth);
                //showAuthentication(response.getWriter(), authentication);
                //RequestDispatcher rd = getServletContext().getRequestDispatcher("/jsp/Response.jsp");
                String url = "http://lbc-dev04/cs/ContentServer?pagename=ThirdPartyLogin"+
            				 "&eMail="+auth.getEmail()+
            				 "&fNm="+auth.getFirstname()+
            				 "&lNm="+auth.getLastname()+
            				 "&gen="+(auth.getGender()==null?"":auth.getGender())+
            				 "&lang="+auth.getLanguage();
                out.println(url);out.flush();
                response.sendRedirect(url);
        	}catch(Exception e){
        		e.printStackTrace();
        		out.println(e);
        	}finally{
        		out.close();
        	}
        	
    		//rd.forward(request, response);
    		//return;
        }
        else if (op.equals("Google")||op.equals("Yahoo")) 
        {
        	PrintWriter out = response.getWriter();
        	out.println("op --->"+op);out.flush();
        	out.println("<html><body>Please Wait ...<img src=\""+request.getContextPath()+"/images/ProgressBar.gif\"></body></html>");
        	out.flush();
        	try{
	            // redirect to Google OR Yahoo sign on page:
	        	out.println("11111");out.flush();
	            Endpoint endpoint = manager.lookupEndpoint(op);
	            out.println("22222"+endpoint);out.flush();
	            Association association = manager.lookupAssociation(endpoint);
	            out.println("33333"+association);out.flush();
	            out.println("33333.11111"+association.getRawMacKey());out.flush();
	            out.println("33333.22222"+endpoint.getAlias());out.flush();
	            request.getSession().setAttribute(ATTR_MAC, association.getRawMacKey());
	            out.println("444444444");out.flush();
	            request.getSession().setAttribute(ATTR_ALIAS, endpoint.getAlias());
	            out.println("5555555555");out.flush();
	            String url = manager.getAuthenticationUrl(endpoint, association);
	            out.println("666666666"+url);out.flush();
	            response.sendRedirect(url);
        	}catch(Exception ex){
        		out.println("<html><body>Error Occured ... Please try after some time</body></html>");
        		out.println(ex);
        		ex.printStackTrace();
        	}finally{
        		out.close();
        	}
            
        }else{
            throw new ServletException("Unsupported OP: " + op);
        }
        
    }



    void checkNonce(String nonce) {
        // check response_nonce to prevent replay-attack:
        if (nonce==null || nonce.length()<20)
            throw new OpenIdException("Verify failed.");
        // make sure the time of server is correct:
        long nonceTime = getNonceTime(nonce);
        long diff = Math.abs(System.currentTimeMillis() - nonceTime);
        if (diff > ONE_HOUR)
            throw new OpenIdException("Bad nonce time.");
        if (isNonceExist(nonce))
            throw new OpenIdException("Verify nonce failed.");
        storeNonce(nonce, nonceTime + TWO_HOUR);
    }

    // simulate a database that store all nonce:
    private Set<String> nonceDb = new HashSet<String>();

    // check if nonce is exist in database:
    boolean isNonceExist(String nonce) {
        return nonceDb.contains(nonce);
    }

    // store nonce in database:
    void storeNonce(String nonce, long expires) {
        nonceDb.add(nonce);
    }

    long getNonceTime(String nonce) {
        try {
            return new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ")
                    .parse(nonce.substring(0, 19) + "+0000")
                    .getTime();
        }
        catch(ParseException e) {
            throw new OpenIdException("Bad nonce time.");
        }
    }
    
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
    		throws ServletException, IOException {
    	doGet(req, resp);
    }
}
